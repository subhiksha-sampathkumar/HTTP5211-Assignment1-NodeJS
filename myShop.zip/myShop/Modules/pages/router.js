const express = require("express");
const pageRouter = express.Router();
const products = require("../myshop/func");

/*load get and post data in json form
pageRouter.use(express.urlencoded({ extended: true }));
pageRouter.use(express.json());*/

//create a webpage
pageRouter.get("/", (request, response) => {
    response.render("home", { title: "Welcome to MyShop!" });
});
    
    pageRouter.get("/Basics", async (request, response) => {   
    links = await products.getProducts("Products");
    //response.status(200).send("Home");
    response.render("products", { title: "HOUSEHOLD PRODUCTS", menu: links });
    });

    pageRouter.get("/Vegetables", async (request, response) => {   
        links = await products.getProducts("Vegetables");
        //response.status(200).send("Home");
        response.render("products", { title: "VEGETABLES", menu: links });
        });

        pageRouter.get("/Office", async (request, response) => {   
            links = await products.getProducts("Office");
            //response.status(200).send("Home");
            response.render("products", { title: "OFFICE SUPPLIES", menu: links });
            });

    pageRouter.get("/About", (request, response) => {
    response.render("about", { title: "About Page for MyShop" });
});

pageRouter.get("/Contact", (request, response) => {
    response.render("contact", { title: "Contact Page for MyShop" });
});
    module.exports = pageRouter;