const express = require("express");
const pageRouter = express.Router();
const products = require("../myshop/func");

/*load get and post data in json form
pageRouter.use(express.urlencoded({ extended: true }));
pageRouter.use(express.json());*/

//create a webpage
    pageRouter.get("/", async (request, response) => {   
    links = await products.getProducts("Products");
    //response.status(200).send("Home");
    response.render("products", { title: "Home Page for MyShop", menu: links });
    });

    pageRouter.get("/Vegetables", async (request, response) => {   
        links = await products.getProducts("Vegetables");
        //response.status(200).send("Home");
        response.render("products", { title: "Home Page for MyShop", menu: links });
        });

        pageRouter.get("/Office", async (request, response) => {   
            links = await products.getProducts("Office");
            //response.status(200).send("Home");
            response.render("products", { title: "Home Page for MyShop", menu: links });
            });

    pageRouter.get("/About", (request, response) => {
    response.status(200).send("About");    
    });

    pageRouter.get("/Contact", (request, response) => {
    response.status(200).send("52 Canadian Road");    
    });

    module.exports = pageRouter;