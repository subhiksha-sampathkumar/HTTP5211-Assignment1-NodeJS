//mongodb
const { MongoClient } = require("mongodb");
//const dbUrl = "mongodb://localhost:27017/shopDB"; //default port is 27017 127.0.0.1
//const dbUrl = "mongodb://127.0.0.1:27017/shopDB";
//const dbUrl = `mongodb+srv://shopBDuser:k5hkz7FgKuyudxtX@cluster0.gkmpswj.mongodb.net/?retryWrites=true&w=majority`
const dbUrl = `mongodb+srv://${process.env.DB_USER}:${process.env.DB_PWD}@${process.env.DB_HOST}/?retryWrites=true&w=majority`;
const client = new MongoClient(dbUrl);  

//mongo helper functions
async function connection() {
    await client.connect();
    db = client.db("shopDB");
    return db;
    }
    
async function getProducts(collName) {
    db = await connection();
    var results = db.collection(collName).find({});
    res = await results.toArray();
    return res;
    }

module.exports = {
    getProducts
};