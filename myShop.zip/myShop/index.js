//import required modules
const express = require("express");
const path = require("path");
const dotenv = require("dotenv");
dotenv.config(); //load our custom environment variables

const pageRouter = require("./Modules/pages/router");

//set up Express object and port
const app = express();
const port = process.env.PORT || "8888";

//pug as template engine for express
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");

//public folder for storing static files
app.use(express.static(path.join(__dirname, "public")));

//load get and post data in json form
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

/*change to display----------------------------------------------see if needed later
app.get("/", async (request, response) => {
    let links = await getLinks();
    response.render("index", { title: "Products", menu: links });
   });
//change to display
app.get("/about", async (request, response) => {
    let links = await getLinks();
    response.render("index", { title: "About", menu: links });
   });*/

/*mongodb
const { MongoClient } = require("mongodb");
//const dbUrl = "mongodb://localhost:27017/shopDB"; //default port is 27017
//const dbUrl = `mongodb+srv://shopBDuser:k5hkz7FgKuyudxtX@cluster0.gkmpswj.mongodb.net/?retryWrites=true&w=majority`
const dbUrl = `mongodb+srv://${process.env.DB_USER}:${process.env.DB_PWD}@${process.env.DB_HOST}/?retryWrites=true&w=majority`;
const client = new MongoClient(dbUrl);  

//create a webpage
   app.get("/", async (request, response) => {   
    let products = await getProducts();
    //response.status(200).send("Home");
    response.render("products", { title: "Home Page for MyShop", menu: products });
   });

   app.get("/About", (request, response) => {
    response.status(200).send("About");    
   });

   app.get("/Contact", (request, response) => {
    response.status(200).send("52 Canadian Road");    
   });*/

app.use("/", pageRouter);

//set up server listening
app.listen(port, () => {
    console.log(`Listening on http://localhost:${port}`);
   });
 
/*mongo helper functions
async function connection() {
    await client.connect();
    db = client.db("shopDB");
    return db;
    }
    
async function getProducts() {
    db = await connection();
    var results = db.collection("Products").find({});
    res = await results.toArray();
    return res;
    }*/
