//import required modules
const express = require("express");
const path = require("path");
const dotenv = require("dotenv");
dotenv.config(); //load our custom environment variables

const pageRouter = require("./Modules/pages/router");

//set up Express object and port
const app = express();
const port = process.env.PORT || "8888";

//pug as template engine for express
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");

//public folder for storing static files
app.use(express.static(path.join(__dirname, "public")));

//load get and post data in json form
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use("/", pageRouter);

//set up server listening
app.listen(port, () => {
    console.log(`Listening on http://localhost:${port}`);
   });
